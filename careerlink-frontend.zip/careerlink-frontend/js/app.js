/* Shared frontend behavior. No backend requests or API keys are used. */
'use strict';

const page = document.body.dataset.page;
const form = document.getElementById('form');
const result = document.getElementById('result');
const fileInput = document.getElementById('file');
const dropZone = document.getElementById('drop');
const fileError = document.getElementById('fileerror');
const MAX_FILE_SIZE = 10 * 1024 * 1024;
let selectedFile = null;

// Mark the current service for assistive technology.
document.querySelectorAll('.nav a.active').forEach(link => {
  link.setAttribute('aria-current', 'page');
});

/** Validate local file metadata only. Server validation is required later. */
function chooseFile(file) {
  if (!file) return;
  result.replaceChildren();
  result.className = '';
  selectedFile = null;
  if (!/\.(pdf|docx)$/i.test(file.name) || file.size === 0 || file.size > MAX_FILE_SIZE) {
    fileError.textContent = 'Choose a non-empty PDF or DOCX file up to 10 MB.';
    document.getElementById('filename').textContent = 'Choose your résumé';
    fileInput.value = '';
    fileInput.setAttribute('aria-invalid', 'true');
    return;
  }
  selectedFile = file;
  fileError.textContent = '';
  fileInput.removeAttribute('aria-invalid');
  document.getElementById('filename').textContent = file.name;
}

if (fileInput) {
  fileInput.setAttribute('aria-describedby', 'fileerror');
  fileInput.addEventListener('change', () => chooseFile(fileInput.files[0]));
  ['dragenter', 'dragover'].forEach(type => {
    dropZone.addEventListener(type, event => {
      event.preventDefault();
      dropZone.classList.add('dragover');
    });
  });
  ['dragleave', 'drop'].forEach(type => {
    dropZone.addEventListener(type, event => {
      event.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });
  dropZone.addEventListener('drop', event => {
    // Keep the native file control consistent with a dropped selection.
    fileInput.value = '';
    chooseFile(event.dataTransfer.files[0]);
  });
}

/** Render fixed UI copy; user-provided values always use textContent. */
function showResult(markup) {
  result.className = 'result';
  result.innerHTML = markup;
  result.setAttribute('tabindex', '-1');
  result.focus({ preventScroll: true });
  result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

if (form) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    if (fileInput && !selectedFile) {
      fileError.textContent = 'Please choose a PDF or DOCX résumé first.';
      fileInput.focus();
      return;
    }
    const company = document.getElementById('company').value;
    if (page === 'queue') {
      const name = document.getElementById('name');
      if (!name.value.trim()) {
        name.setCustomValidity('Please enter your name.');
        name.reportValidity();
        name.addEventListener('input', () => name.setCustomValidity(''), { once: true });
        return;
      }
      showResult(`<strong>You’re in the demo queue.</strong>
        <p id="queue-company"></p><div class="score">#07</div>
        <div>Estimated wait: 21 minutes</div>
        <p class="small">Sample confirmation only. No live place has been reserved or notification sent.</p>`);
      document.getElementById('queue-company').textContent = company;
    } else if (page === 'upload') {
      showResult(`<strong>Your demo submission is ready.</strong>
        <p id="submission-summary"></p>
        <span class="small">The file was selected locally. It has not been uploaded or sent.</span>`);
      document.getElementById('submission-summary').textContent = `${selectedFile.name} → ${company}`;
    } else if (page === 'analyze') {
      showResult(`<span class="tag">SAMPLE RESULTS · NOT AI GENERATED</span>
        <p id="analysis-target"></p>
        <div class="score">78<span class="score-unit">%</span></div>
        <strong>Example role alignment</strong>
        <div class="progress" role="img" aria-label="Example alignment: 78 percent"><span></span></div>
        <strong>Potential strengths</strong>
        <p>Technical foundations, collaborative projects, and clear communication.</p>
        <strong>Ways to strengthen your résumé</strong>
        <p>Quantify project results. Highlight tools relevant to the role. Add a concise example of problem solving.</p>
        <p class="small">This is a fixed example. Your résumé has not been read or scored.</p>`);
      document.getElementById('analysis-target').textContent = `${company} · ${document.getElementById('role').value}`;
    }
  });

  // Hide stale confirmations when the selected company, role or details change.
  form.addEventListener('input', event => {
    if (event.target === fileInput) return;
    result.replaceChildren();
    result.className = '';
  });
}
